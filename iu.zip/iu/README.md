# How to run

## Backend
Docker engine is required on computer
`cd ./backend && docker-compose up`

## Frontend
Nodejs and npm are required on computer
`cd ./frontend && npm i && npm run dev`

# How to test
Tests are unfortunately missing
