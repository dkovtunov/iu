export const kafkaConfig = {};
