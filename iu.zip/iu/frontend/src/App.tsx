import './App.css'
import {RegistrationForm} from "./components/user/register/RegistrationForm.tsx";

function App() {

  return (
      <RegistrationForm />
  )
}

export default App
